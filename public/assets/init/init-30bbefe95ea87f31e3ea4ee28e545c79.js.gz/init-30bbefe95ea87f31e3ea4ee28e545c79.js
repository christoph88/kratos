jQuery(document).ready(function() {
  App.init();
});
