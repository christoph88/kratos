jQuery(document).ready(function() {
  App.init();
  App.initCounter();
  App.initParallaxBg();
  OwlCarousel.initOwlCarousel();
});
